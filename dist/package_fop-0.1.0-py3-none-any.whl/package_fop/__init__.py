# from package_fop import config

# with open(config.VERSION_PATH,'r') as fp:
#     __version__ = fp.read().strip()
__version__ = "0.1.0"